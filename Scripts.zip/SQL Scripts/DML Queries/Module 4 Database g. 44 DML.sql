USE SQL_quiz;

#in our DDL script, we created the tables, now we need to add values into these tables, starting off, we have the storage for
#our user info, moving on to our quiz questions and then finally we have each answer of each of the users
INSERT INTO user 
VALUES 
	('1001','Alexander_Cortez','alex.165@gmail.com','+346555538','Spain','37.5','50','12.5'),
	('1002','Sergei_Polunin','sergei.polunin.89@gmail.com','+38091657719','Ukraine','50','50','00'),
	('1003','Mohammad_Hossain','mohammad.hoss@gmail.com','+92518355600',NULL,'42.87','14.26','42.87'),
    ('1004','Pawel_Kaczmarek','pawkacz@gmail.com','+48224202020','Poland','40','40','20'),
    ('1005','Mikkel_Nielsen','mikkel.nielsen@gmail.com','+4561470675','Denmark','25','37.5','37.5'),
    ('1006','Fatema_Alam','fatemalam7@gmail.com','+88029668855','Bangladesh','44.44','44.44','11.11'),
    ('1007','Matilde_Hansen','mat.han.55@gmail.com','+4559821372',NULL,'16.67','33.33','50'),
    ('1008','Petr_Zeleny','petr.zel.19@gmail.com','+420557381481 ',NULL,'28.57','28.57','42.86'),
    ('1009','Claudia_Schubert','claudy.137@gmail.com','+437629','Austria','33.33','16.67','50'),
    ('1010','Jana_Vojtkova','jana.vojty.56@gmail.com','+421938698722',NULL,'33.33','16.67','50'),
    ('1011','Simo_Aalto','aalto.43@gmail.com','+3589551243','Finland','20','40','40'),
    ('1012','Vladimir_Malkin','malkin.vlad@gmail.com','+76529713557','Russia','25','37.5','37.5');
    
     
    
INSERT INTO questions
VALUES
	('1','Creative','Would you prefer a more expensive product with extensive detailwork over a cheaper average looking product?'),
    ('2','Development','Have you ever tried any coding course, or self study of coding before?'),
    ('3','Digita_Marketing','Have you ever studied the statistics tab in settings of any social platform?'),
    ('4','Development','Did you ever try to create a website using any templates before?'),
    ('5','Digital_Marketing','Do you think the advertisements on social platforms are more effective than any other form of ads?'),
    ('6','Creative','Are you inclined to editing videos, even simple ones like insta story or twitch.tv clip?'),
    ('7','Creative','Would you say that you are confident enough about creating a presentation in whatever software you prefer?'),
    ('8','Development','Would you ever want to try to take a part in a TV show with some form of quiz or intelligence battle?'),
    ('9','Digital_Marketing','Do you spend more than 3 hours on social platforms daily ?'),
    ('10','Development','Would you prefer solving logical problems over trying to better understand some phylosophical terms?'),
    ('11','Digital_Marketing','Have you ever noticed that after searching for a certain product, you can see ads for it on Social Media?'),
    ('12','Creative','Did you ever visit the gallery just to see one specific painting?');
    
INSERT INTO answers
VALUES
	('1001','1','YES','2016-04-03'),
    ('1001','2','YES','2016-04-03'),
    ('1001','3','NO','2016-04-03'),
    ('1001','4','YES','2016-04-03'),
    ('1001','5','NO','2016-04-03'),
    ('1001','6','YES','2016-04-03'),
    ('1001','7','YES','2016-04-03'),
    ('1001','8','YES','2016-04-03'),
    ('1001','9','NO','2016-04-03'),
    ('1001','10','YES','2016-04-03'),
    ('1001','11','YES','2016-04-03'),
    ('1001','12','NO','2016-04-03'),
    ('1002','1','YES','2016-06-09'),
    ('1002','2','NO','2016-06-09'),
    ('1002','3','NO','2016-06-09'),
    ('1002','4','YES','2016-06-09'),
    ('1002','5','NO','2016-06-09'),
    ('1002','6','YES','2016-06-09'),
    ('1002','7','NO','2016-06-09'),
    ('1002','8','NO','2016-06-09'),
    ('1002','9','NO','2016-06-09'),
    ('1002','10','YES','2016-06-09'),
    ('1002','11','NO','2016-06-09'),
    ('1002','12','NO','2016-06-09'),
    ('1003','1','NO','2019-11-24'),
    ('1003','2','YES','2019-11-24'),
    ('1003','3','YES','2019-11-24'),
    ('1003','4','YES','2019-11-24'),
    ('1003','5','YES','2019-11-24'),
    ('1003','6','NO','2019-11-24'),
    ('1003','7','NO','2019-11-24'),
    ('1003','8','YES','2019-11-24'),
    ('1003','9','NO','2019-11-24'),
    ('1003','10','NO','2019-11-24'),
    ('1003','11','YES','2019-11-24'),
    ('1003','12','YES','2019-11-24'),
    ('1004','1','NO','2015-08-09'),
    ('1004','2','YES','2015-08-09'),
    ('1004','3','NO','2015-08-09'),
    ('1004','4','YES','2015-08-09'),
    ('1004','5','YES','2015-08-09'),
    ('1004','6','NO','2015-08-09'),
    ('1004','7','YES','2015-08-09'),
    ('1004','8','NO','2015-08-09'),
    ('1004','9','NO','2015-08-09'),
    ('1004','10','NO','2015-08-09'),
    ('1004','11','NO','2015-08-09'),
    ('1004','12','YES','2015-08-09'),
    ('1005','1','YES','2019-11-24'),
    ('1005','2','YES','2019-11-24'),
    ('1005','3','YES','2019-11-24'),
    ('1005','4','YES','2019-11-24'),
    ('1005','5','YES','2019-11-24'),
    ('1005','6','NO','2019-11-24'),
    ('1005','7','NO','2019-11-24'),
    ('1005','8','YES','2019-11-24'),
    ('1005','9','NO','2019-11-24'),
    ('1005','10','NO','2019-11-24'),
    ('1005','11','YES','2019-11-24'),
    ('1005','12','YES','2019-11-24'),
    ('1006','1','YES','2020-04-20'),
    ('1006','2','YES','2020-04-20'),
    ('1006','3','YES','2020-04-20'),
    ('1006','4','YES','2020-04-20'),
    ('1006','5','NO','2020-04-20'),
    ('1006','6','YES','2020-04-20'),
    ('1006','7','YES','2020-04-20'),
    ('1006','8','YES','2020-04-20'),
    ('1006','9','NO','2020-04-20'),
    ('1006','10','YES','2020-04-20'),
    ('1006','11','NO','2020-04-20'),
    ('1006','12','YES','2020-04-20'),
    ('1007','1','NO','2018-01-17'),
    ('1007','2','YES','2018-01-17'),
    ('1007','3','NO','2018-01-17'),
    ('1007','4','NO','2018-01-17'),
    ('1007','5','YES','2018-01-17'),
    ('1007','6','NO','2018-01-17'),
    ('1007','7','YES','2018-01-17'),
    ('1007','8','YES','2018-01-17'),
    ('1007','9','YES','2018-01-17'),
    ('1007','10','NO','2018-01-17'),
    ('1007','11','YES','2018-01-17'),
    ('1007','12','NO','2018-01-17'),
    ('1008','1','NO','2016-02-18'),
    ('1008','2','NO','2016-02-18'),
    ('1008','3','YES','2016-02-18'),
    ('1008','4','NO','2016-02-18'),
    ('1008','5','YES','2016-02-18'),
    ('1008','6','YES','2016-02-18'),
    ('1008','7','NO','2016-02-18'),
    ('1008','8','YES','2016-02-18'),
    ('1008','9','NO','2016-02-18'),
    ('1008','10','YES','2016-02-18'),
    ('1008','11','YES','2016-02-18'),
    ('1008','12','YES','2016-02-18'),
    ('1009','1','YES','2021-01-5'),
    ('1009','2','NO','2021-01-5'),
    ('1009','3','YES','2021-01-5'),
    ('1009','4','NO','2021-01-5'),
    ('1009','5','NO','2021-01-5'),
    ('1009','6','NO','2021-01-5'),
    ('1009','7','NO','2021-01-5'),
    ('1009','8','YES','2021-01-5'),
    ('1009','9','YES','2021-01-5'),
    ('1009','10','NO','2021-01-5'),
    ('1009','11','YES','2021-01-5'),
    ('1009','12','YES','2021-01-5'),
    ('1010','1','NO','2017-04-01'),
    ('1010','2','NO','2017-04-01'),
    ('1010','3','NO','2017-04-01'),
    ('1010','4','NO','2017-04-01'),
    ('1010','5','YES','2017-04-01'),
    ('1010','6','YES','2017-04-01'),
    ('1010','7','NO','2017-04-01'),
    ('1010','8','YES','2017-04-01'),
    ('1010','9','YES','2017-04-01'),
    ('1010','10','NO','2017-04-01'),
    ('1010','11','YES','2017-04-01'),
    ('1010','12','YES','2017-04-01'),
    ('1011','1','NO','2016-04-03'),
    ('1011','2','NO','2016-04-03'),
    ('1011','3','YES','2016-04-03'),
    ('1011','4','YES','2016-04-03'),
    ('1011','5','NO','2016-04-03'),
    ('1011','6','NO','2016-04-03'),
    ('1011','7','YES','2016-04-03'),
    ('1011','8','NO','2016-04-03'),
    ('1011','9','YES','2016-04-03'),
    ('1011','10','YES','2016-04-03'),
    ('1011','11','NO','2016-04-03'),
    ('1011','12','NO','2016-04-03'),
    ('1012','1','YES','2020-11-25'),
    ('1012','2','YES','2020-11-25'),
    ('1012','3','YES','2020-11-25'),
    ('1012','4','NO','2020-11-25'),
    ('1012','5','YES','2020-11-25'),
    ('1012','6','NO','2020-11-25'),
    ('1012','7','NO','2020-11-25'),
    ('1012','8','YES','2020-11-25'),
    ('1012','9','NO','2020-11-25'),
    ('1012','10','YES','2020-11-25'),
    ('1012','11','YES','2020-11-25'),
    ('1012','12','YES','2020-11-25');
    
#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

#this select command can be used to view the join of questions and answers tables the values  
#these values can be filtered, counted and evaluated by using if statement in python for example
#once we evaluate each user according to his YES ANSWERS in a particular CATEGORY we can paste the results into the attributes of the user under each category
#with that information at hand, we can recommend the best fitting courses for each user
  
SELECT q.Question_ID, a.User_ID, q.Category, q.Question, a.Answer, a.Time
FROM questions as q
LEFT JOIN answers as a
	ON q.Question_ID=a.Question_ID;




    
    
    
    
    
    
    
    
    
