CREATE DATABASE SQL_Quiz; #creates a database for our quiz app
USE SQL_Quiz; #uses our database to later on store information into it

#tables will help us spread the relevant info in our database
CREATE TABLE `Answers` (
  `User_ID` INT,
  `Question_ID` INT,
  `Answer` VARCHAR(3),
  `Time` DATE,
  PRIMARY KEY (`User_ID`, `Question_ID`)
);

#upon using CREATE TABLE to create the table, we put in every attribute we drafted in a relational model earlier
#we also have constraints which certain create borders for our data input
#we assign a primary key, in this case we are using the composite key, joining up two foreign keys



CREATE TABLE `Questions` (
  `Question_ID` INT,
  `Category` VARCHAR(17),
  `Question` VARCHAR(500),
  PRIMARY KEY (`Question_ID`)
);

CREATE TABLE `User` (
  `User_ID` INT,
  `Full_Name` VARCHAR(255),
  `Email` VARCHAR(30),
  `Phone_Number` VARCHAR(50),
  `Country(optional)` VARCHAR(56),
  `Creative(%)` DECIMAL (4,2),
  `Development(%)` DECIMAL (4,2),
  `DigitalMarketing(%)` DECIMAL (4,2),
  PRIMARY KEY (`User_ID`)
);

